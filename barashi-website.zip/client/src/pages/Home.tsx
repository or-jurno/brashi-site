/*
 * Design Philosophy: Premium Real Estate Elegance
 * Navy #1F365C | White #FFFFFF | Light Gray #F7F8FA | Gold accent #C9A96E
 * Font: Heebo — Bold headings, Regular body
 * RTL-first, luxury whitespace, smooth scroll animations
 */

import { useEffect, useRef, useState } from "react";

// ─── Asset URLs ───────────────────────────────────────────────────────────────
const LOGO_URL = "/manus-storage/barashi-logo-transparent_70ab148f.png";
const LOGO_WHITE_URL = "/manus-storage/barashi-logo-white_16c294a7.png";
const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663383441189/ez2yck4AggbZoiWhFD5aYc/telaviv-hero-bApJyeennKtdAoCQu4UQ2e.webp";
const BLUEPRINT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663383441189/ez2yck4AggbZoiWhFD5aYc/blueprint-section-RKDK8DKCNUnxS7LaFFjvCF.webp";
const MGMT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663383441189/ez2yck4AggbZoiWhFD5aYc/building-management-PSM2VF2rhxniVg2zxdXtew.webp";
const BUILDING_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663383441189/ez2yck4AggbZoiWhFD5aYc/luxury-building-Qx6j7uBMM6QZYZYAfMrjNc.webp";

// ─── Service Cards Data ───────────────────────────────────────────────────────
const services = [
  {
    icon: "📐",
    title: "תכנון תפעולי מוקדם",
    desc: "ניתוח תכניות אדריכליות והנדסיות בהיבטי תחזוקה ותפעול, כתיבת פרוגרמות תפעוליות והגדרת מערכי שירות ותפעול.",
  },
  {
    icon: "⚙️",
    title: "ליווי תכנון מערכות",
    desc: "בחינת מערכות המבנה והתאמתן לדרישות תפעול ותחזוקה, כולל איתור פערים ומתן פתרונות.",
  },
  {
    icon: "🏗️",
    title: "ליווי ביצוע ומסירה",
    desc: "בקרה תפעולית בשטח, בדיקות Commissioning וליווי תהליכי מסירה ואכלוס.",
  },
  {
    icon: "📋",
    title: "הקמת מערך תפעול וניהול",
    desc: "הגדרת תכולות שירות, כתיבת SLA, ליווי מכרזים ובניית תוכניות תחזוקה ו-KPI.",
  },
  {
    icon: "🔍",
    title: "בקרה וייעוץ שוטף",
    desc: "ביקורות תקופתיות, ייעול עלויות תפעול וליווי מקצועי לצוותי ניהול ואחזקה.",
  },
];

const checkItems = [
  "מניעת טעויות תפעול יקרות כבר בשלבי התכנון",
  "הקטנת עלויות תחזוקה לאורך זמן",
  "תפעול יעיל ויציב מרגע האכלוס",
  "התאמה מלאה בין תכנון לפרקטיקה בשטח",
  "שקט תפעולי וניהול נכס ברמה גבוהה",
];

const navLinks = [
  { label: "מי אנחנו", href: "#about" },
  { label: "תחומי פעילות", href: "#services" },
  { label: "הערך ללקוח", href: "#value" },
  { label: "ניסיון", href: "#experience" },
  { label: "צור קשר", href: "#contact" },
];

// ─── Reveal Hook ──────────────────────────────────────────────────────────────
function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("visible");
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return ref;
}

// ─── Section Title Component ──────────────────────────────────────────────────
function SectionTitle({
  title,
  center = false,
  light = false,
}: {
  title: string;
  center?: boolean;
  light?: boolean;
}) {
  const ref = useReveal();
  return (
    <div
      ref={ref}
      className={`reveal mb-12 ${center ? "text-center" : ""}`}
    >
      {center ? (
        <div className="gold-divider-center mb-4" />
      ) : (
        <div className="gold-divider mb-4" />
      )}
      <h2
        className={`text-3xl md:text-4xl font-bold leading-tight ${
          light ? "text-white" : "text-navy"
        }`}
        style={{ fontFamily: "'Heebo', sans-serif" }}
      >
        {title}
      </h2>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [formData, setFormData] = useState({ name: "", phone: "", message: "" });
  const [formSent, setFormSent] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Reveal all elements on page
  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.08 }
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSent(true);
  };

  return (
    <div dir="rtl" className="min-h-screen" style={{ fontFamily: "'Heebo', sans-serif" }}>

      {/* ─── STICKY NAVIGATION ─────────────────────────────────────────────── */}
      <nav
        className={`sticky-nav ${scrolled ? "scrolled" : "bg-transparent"}`}
        style={{
          backgroundColor: scrolled ? "rgba(31, 54, 92, 0.97)" : "transparent",
          backdropFilter: scrolled ? "blur(10px)" : "none",
          boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.2)" : "none",
        }}
      >
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          {/* Logo in nav — white version */}
          <a href="#hero" className="flex items-center gap-3">
            <img
              src={LOGO_WHITE_URL}
              alt="לוגו בראשי"
              className="h-11 w-auto"
            />
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-white/90 hover:text-white font-medium text-sm transition-colors duration-200 hover:text-yellow-300"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <a
            href="tel:0545410877"
            className="hidden md:inline-flex items-center gap-2 px-5 py-2.5 rounded text-sm font-bold transition-all duration-300"
            style={{
              backgroundColor: "oklch(0.72 0.09 75)",
              color: "oklch(0.18 0.04 250)",
              fontFamily: "'Heebo', sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.65 0.09 75)";
              (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.72 0.09 75)";
              (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
            }}
          >
            📞 054-5410877
          </a>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="תפריט"
          >
            <div className="w-6 h-0.5 bg-white mb-1.5 transition-all" />
            <div className="w-6 h-0.5 bg-white mb-1.5 transition-all" />
            <div className="w-6 h-0.5 bg-white transition-all" />
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div
            className="md:hidden py-4 px-6"
            style={{ backgroundColor: "rgba(31, 54, 92, 0.98)" }}
          >
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="block py-3 text-white/90 hover:text-white font-medium border-b border-white/10"
                onClick={() => setMobileOpen(false)}
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                {link.label}
              </a>
            ))}
            <a
              href="tel:0545410877"
              className="block mt-4 text-center py-3 rounded font-bold"
              style={{ backgroundColor: "oklch(0.72 0.09 75)", color: "oklch(0.18 0.04 250)" }}
            >
              📞 054-5410877
            </a>
          </div>
        )}
      </nav>

      {/* ─── SECTION 1: HERO ────────────────────────────────────────────────── */}
      <section
        id="hero"
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url(${HERO_BG})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Dark overlay — lighter so the Tel Aviv skyline shows through */}
        <div
          className="absolute inset-0"
          style={{
            background: "linear-gradient(to bottom, rgba(15,28,58,0.72) 0%, rgba(20,38,70,0.55) 40%, rgba(10,22,50,0.78) 100%)",
          }}
        />

        {/* Content */}
        <div className="relative z-10 container mx-auto px-6 text-center py-32">
          {/* Logo — large white version on dark hero */}
          <div className="animate-fade-up mb-10 flex justify-center">
            <img
              src={LOGO_WHITE_URL}
              alt="בראשי ניהול מבנים חכם"
              className="h-44 md:h-56 w-auto"
              style={{
                filter: "drop-shadow(0 4px 24px rgba(0,0,0,0.6))",
              }}
            />
          </div>

          {/* Main Heading */}
          <h1
            className="animate-fade-up-delay-1 text-4xl md:text-6xl lg:text-7xl font-black text-white leading-tight mb-6"
            style={{ fontFamily: "'Heebo', sans-serif", textShadow: "0 2px 20px rgba(0,0,0,0.3)" }}
          >
            ניהול מבנים חכם
            <br />
            <span style={{ color: "oklch(0.72 0.09 75)" }}>מתחיל בתכנון נכון</span>
          </h1>

          {/* Subtitle */}
          <p
            className="animate-fade-up-delay-2 text-xl md:text-2xl text-white/80 font-light mb-6 max-w-2xl mx-auto"
            style={{ fontFamily: "'Heebo', sans-serif" }}
          >
            שירותי ייעוץ וליווי בתחום אחזקה ותפעול נכסים
          </p>

          {/* Body text */}
          <p
            className="animate-fade-up-delay-2 text-base md:text-lg text-white/70 mb-12 max-w-xl mx-auto leading-relaxed"
            style={{ fontFamily: "'Heebo', sans-serif" }}
          >
            ליווי יזמים וחברות נדל״ן בהיבטי אחזקה ותפעול נכסים כבר בשלבי התכנון — כדי להבטיח תפעול יעיל, חסכוני ויציב לאורך שנים.
          </p>

          {/* CTA Buttons */}
          <div className="animate-fade-up-delay-3 flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#contact"
              className="btn-primary text-base px-8 py-4 font-bold rounded"
              style={{ fontFamily: "'Heebo', sans-serif" }}
            >
              לתיאום שיחה
            </a>
            <a
              href="#contact"
              className="btn-outline text-base px-8 py-4 font-semibold rounded"
              style={{ fontFamily: "'Heebo', sans-serif" }}
            >
              יצירת קשר
            </a>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center pt-2">
              <div className="w-1 h-3 bg-white/60 rounded-full" />
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 2: מי אנחנו ─────────────────────────────────────────────── */}
      <section id="about" className="section-padding bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Text */}
            <div>
              <SectionTitle title="מי אנחנו ומה הערך שלנו" />
              <div className="reveal reveal-delay-1">
                <p
                  className="text-lg leading-relaxed mb-6"
                  style={{ color: "oklch(0.35 0.04 250)", fontFamily: "'Heebo', sans-serif" }}
                >
                  בראשי ניהול מבנים חכם מלווה יזמים וחברות נדל״ן בהיבטי אחזקה ותפעול נכסים כבר בשלבי התכנון, במטרה להבטיח שהפרויקט לא רק מתוכנן נכון — אלא גם ניתן לתפעול יעיל, חסכוני ויציב לאורך זמן.
                </p>
                <p
                  className="text-lg leading-relaxed"
                  style={{ color: "oklch(0.35 0.04 250)", fontFamily: "'Heebo', sans-serif" }}
                >
                  הייעוץ מתמקד בגישור על הפער בין תכנון לביצוע בפועל, תוך התאמה לצרכים תפעוליים מורכבים, לרבות פרויקטים של עירוב שימושים, מבני משרדים, מגורים ומסחר.
                </p>
              </div>

              {/* Feature icons */}
              <div className="reveal reveal-delay-2 grid grid-cols-3 gap-6 mt-10">
                {[
                  { icon: "🏛️", label: "מקצועיות" },
                  { icon: "🔧", label: "תפעול חכם" },
                  { icon: "📊", label: "תכנון מדויק" },
                ].map((item) => (
                  <div key={item.label} className="text-center">
                    <div className="text-4xl mb-2">{item.icon}</div>
                    <div
                      className="text-sm font-semibold text-navy"
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    >
                      {item.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Image */}
            <div className="reveal reveal-delay-2">
              <div className="relative">
                <img
                  src={BUILDING_IMG}
                  alt="מבנה יוקרתי"
                  className="w-full h-80 lg:h-96 object-cover rounded-lg shadow-2xl"
                />
                {/* Accent box */}
                <div
                  className="absolute -bottom-6 -right-6 w-32 h-32 rounded-lg hidden lg:block"
                  style={{ backgroundColor: "oklch(0.72 0.09 75)", opacity: 0.15 }}
                />
                <div
                  className="absolute -top-4 -left-4 w-20 h-20 rounded-lg hidden lg:block border-2"
                  style={{ borderColor: "oklch(0.28 0.07 250)", opacity: 0.2 }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 3: תחומי פעילות ─────────────────────────────────────────── */}
      <section
        id="services"
        className="section-padding"
        style={{ backgroundColor: "#F7F8FA" }}
      >
        <div className="container mx-auto px-6">
          <SectionTitle title="תחומי הפעילות" center />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
            {services.map((service, i) => (
              <div
                key={service.title}
                className={`reveal reveal-delay-${Math.min(i + 1, 5)} service-card bg-white rounded-lg p-8 shadow-sm border border-gray-100`}
                style={{
                  borderTop: "3px solid oklch(0.28 0.07 250)",
                }}
              >
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3
                  className="text-xl font-bold text-navy mb-3"
                  style={{ fontFamily: "'Heebo', sans-serif" }}
                >
                  {service.title}
                </h3>
                <p
                  className="text-base leading-relaxed"
                  style={{ color: "oklch(0.45 0.03 250)", fontFamily: "'Heebo', sans-serif" }}
                >
                  {service.desc}
                </p>
              </div>
            ))}

            {/* Last card — CTA */}
            <div
              className="reveal reveal-delay-5 service-card rounded-lg p-8 flex flex-col justify-center items-center text-center"
              style={{ backgroundColor: "oklch(0.28 0.07 250)" }}
            >
              <div className="text-4xl mb-4">💬</div>
              <h3
                className="text-xl font-bold text-white mb-3"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                יש לכם פרויקט?
              </h3>
              <p
                className="text-white/80 mb-6 text-sm leading-relaxed"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                נשמח לשמוע על הצרכים שלכם ולהציע פתרון מותאם
              </p>
              <a
                href="#contact"
                className="btn-primary text-sm px-6 py-3"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                צרו קשר
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 4: הערך ללקוח ───────────────────────────────────────────── */}
      <section id="value" className="section-padding bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <div className="reveal order-2 lg:order-1">
              <img
                src={BLUEPRINT_IMG}
                alt="שרטוטים אדריכליים"
                className="w-full h-80 lg:h-96 object-cover rounded-lg shadow-xl"
              />
            </div>

            {/* Checklist */}
            <div className="order-1 lg:order-2">
              <SectionTitle title="הערך ללקוח" />
              <div className="reveal reveal-delay-1">
                {checkItems.map((item, i) => (
                  <div key={i} className="check-item">
                    <div
                      className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center mt-0.5"
                      style={{ backgroundColor: "oklch(0.28 0.07 250)" }}
                    >
                      <svg
                        className="w-4 h-4 text-white"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={3}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                    <p
                      className="text-base font-medium"
                      style={{ color: "oklch(0.25 0.04 250)", fontFamily: "'Heebo', sans-serif" }}
                    >
                      {item}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 5: ניסיון ויישום ────────────────────────────────────────── */}
      <section
        id="experience"
        className="section-padding relative overflow-hidden"
        style={{ backgroundColor: "oklch(0.28 0.07 250)" }}
      >
        {/* Background image overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url(${MGMT_IMG})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />

        <div className="relative z-10 container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <SectionTitle title="ניסיון ויישום" center light />

            <div className="reveal reveal-delay-1">
              <p
                className="text-lg md:text-xl text-white/85 leading-relaxed mb-8"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                הייעוץ מבוסס על ניסיון מעשי בניהול ותפעול מבנים ונכסים, לצד עבודה שוטפת מול יזמים, קבלנים וחברות נדל״ן.
              </p>
              <p
                className="text-lg md:text-xl text-white/85 leading-relaxed"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                הדגש הוא על יישום פרקטי של פתרונות תפעוליים כבר בשלבי התכנון, מתוך היכרות עמוקה עם אתגרי ההפעלה בפועל.
              </p>
            </div>

            {/* Stats */}
            <div className="reveal reveal-delay-2 grid grid-cols-3 gap-8 mt-14">
              {[
                { num: "15+", label: "שנות ניסיון" },
                { num: "50+", label: "פרויקטים" },
                { num: "100%", label: "מקצועיות" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div
                    className="text-4xl md:text-5xl font-black mb-2"
                    style={{ color: "oklch(0.72 0.09 75)", fontFamily: "'Heebo', sans-serif" }}
                  >
                    {stat.num}
                  </div>
                  <div
                    className="text-white/70 text-sm font-medium"
                    style={{ fontFamily: "'Heebo', sans-serif" }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 6: CONTACT ──────────────────────────────────────────────── */}
      <section
        id="contact"
        className="section-padding"
        style={{ backgroundColor: "oklch(0.20 0.07 250)" }}
      >
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Contact Info */}
            <div>
              <SectionTitle title="בואו נדבר" light />

              <div className="reveal reveal-delay-1 space-y-6">
                {/* Name */}
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "oklch(0.72 0.09 75)" }}
                  >
                    <span className="text-xl">👤</span>
                  </div>
                  <div>
                    <p className="text-white/60 text-sm" style={{ fontFamily: "'Heebo', sans-serif" }}>
                      איש קשר
                    </p>
                    <p className="text-white font-bold text-lg" style={{ fontFamily: "'Heebo', sans-serif" }}>
                      איציק בראשי
                    </p>
                    <p className="text-white/70 text-sm" style={{ fontFamily: "'Heebo', sans-serif" }}>
                      בראשי ניהול מבנים חכם
                    </p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "oklch(0.72 0.09 75)" }}
                  >
                    <span className="text-xl">📞</span>
                  </div>
                  <div>
                    <p className="text-white/60 text-sm" style={{ fontFamily: "'Heebo', sans-serif" }}>
                      טלפון
                    </p>
                    <a
                      href="tel:0545410877"
                      className="text-white font-bold text-xl hover:text-yellow-300 transition-colors"
                      style={{ fontFamily: "'Heebo', sans-serif", direction: "ltr", display: "block" }}
                    >
                      054-5410877
                    </a>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <a
                    href="tel:0545410877"
                    className="flex items-center justify-center gap-2 px-6 py-3.5 rounded font-bold text-sm transition-all duration-300"
                    style={{
                      backgroundColor: "oklch(0.72 0.09 75)",
                      color: "oklch(0.18 0.04 250)",
                      fontFamily: "'Heebo', sans-serif",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
                      (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 20px rgba(201,169,110,0.35)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                      (e.currentTarget as HTMLElement).style.boxShadow = "none";
                    }}
                  >
                    📞 חיוג ישיר
                  </a>
                  <a
                    href="https://wa.me/972545410877"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 px-6 py-3.5 rounded font-bold text-sm transition-all duration-300"
                    style={{
                      backgroundColor: "#25D366",
                      color: "white",
                      fontFamily: "'Heebo', sans-serif",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
                      (e.currentTarget as HTMLElement).style.backgroundColor = "#1ebe5d";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                      (e.currentTarget as HTMLElement).style.backgroundColor = "#25D366";
                    }}
                  >
                    <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                    </svg>
                    WhatsApp
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="reveal reveal-delay-2">
              {formSent ? (
                <div
                  className="rounded-lg p-10 text-center"
                  style={{ backgroundColor: "oklch(0.25 0.07 250)" }}
                >
                  <div className="text-5xl mb-4">✅</div>
                  <h3
                    className="text-2xl font-bold text-white mb-2"
                    style={{ fontFamily: "'Heebo', sans-serif" }}
                  >
                    תודה על פנייתך!
                  </h3>
                  <p
                    className="text-white/70"
                    style={{ fontFamily: "'Heebo', sans-serif" }}
                  >
                    נחזור אליך בהקדם.
                  </p>
                </div>
              ) : (
                <form
                  onSubmit={handleFormSubmit}
                  className="rounded-lg p-8 space-y-5"
                  style={{ backgroundColor: "oklch(0.25 0.07 250)" }}
                >
                  <h3
                    className="text-xl font-bold text-white mb-6"
                    style={{ fontFamily: "'Heebo', sans-serif" }}
                  >
                    שלחו לנו הודעה
                  </h3>

                  <div>
                    <label
                      className="block text-white/70 text-sm mb-2"
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    >
                      שם מלא *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="form-input"
                      placeholder="הכנס שם מלא"
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    />
                  </div>

                  <div>
                    <label
                      className="block text-white/70 text-sm mb-2"
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    >
                      טלפון *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="form-input"
                      placeholder="05X-XXXXXXX"
                      style={{ fontFamily: "'Heebo', sans-serif", direction: "ltr", textAlign: "right" }}
                    />
                  </div>

                  <div>
                    <label
                      className="block text-white/70 text-sm mb-2"
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    >
                      הודעה
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="form-input resize-none"
                      placeholder="ספרו לנו על הפרויקט שלכם..."
                      style={{ fontFamily: "'Heebo', sans-serif" }}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded font-bold text-base transition-all duration-300"
                    style={{
                      backgroundColor: "oklch(0.72 0.09 75)",
                      color: "oklch(0.18 0.04 250)",
                      fontFamily: "'Heebo', sans-serif",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.65 0.09 75)";
                      (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.72 0.09 75)";
                      (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                    }}
                  >
                    שלח הודעה
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ─── FOOTER ──────────────────────────────────────────────────────────── */}
      <footer
        className="py-8 border-t"
        style={{
          backgroundColor: "oklch(0.15 0.06 250)",
          borderColor: "oklch(0.25 0.06 250)",
        }}
      >
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
              src={LOGO_WHITE_URL}
              alt="בראשי"
              className="h-9 w-auto"
              style={{ opacity: 0.8 }}
            />
            </div>
            <p
              className="text-sm"
              style={{ color: "oklch(0.55 0.03 250)", fontFamily: "'Heebo', sans-serif" }}
            >
              © {new Date().getFullYear()} בראשי ניהול מבנים חכם. כל הזכויות שמורות.
            </p>
            <p
              className="text-sm"
              style={{ color: "oklch(0.55 0.03 250)", fontFamily: "'Heebo', sans-serif" }}
            >
              <a
                href="http://www.barashi.net"
                className="hover:text-white transition-colors"
                style={{ fontFamily: "'Heebo', sans-serif" }}
              >
                www.barashi.net
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
